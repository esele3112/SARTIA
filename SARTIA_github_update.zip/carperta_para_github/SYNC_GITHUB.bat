REM ====================================================================
REM  SARTIA - Sincronizar repositorio GitHub con el codigo local
REM  Requiere: git instalado y permisos de escritura en
REM  https://github.com/esele3112/SARTIA
REM ====================================================================
@echo off
setlocal
set REPO=https://github.com/esele3112/SARTIA.git
set RAMA=main

REM 1) Clonar (o entrar a la copia existente)
if not exist SARTIA (
    git clone %REPO%
    if errorlevel 1 goto :error
)
cd SARTIA

REM 2) Traer ultimo estado remoto y cambiar a main
git fetch origin
git checkout %RAMA%
git pull origin %RAMA%
if errorlevel 1 goto :error

REM 3) Copiar los archivos locales (ajustar RUTA_LOCAL a tu carpeta)
set RUTA_LOCAL=C:\ruta\a\tus\archivos\SARTIA
copy /Y "%RUTA_LOCAL%\app.py"                    app.py
copy /Y "%RUTA_LOCAL%\shap_utils.py"            shap_utils.py
copy /Y "%RUTA_LOCAL%\etl_sartia.py"            etl_sartia.py
copy /Y "%RUTA_LOCAL%\entrenar_modelo.py"       entrenar_modelo.py
copy /Y "%RUTA_LOCAL%\sincronizar_google_sheets.py" sincronizar_google_sheets.py
copy /Y "%RUTA_LOCAL%\generar_datos_demo.py"    generar_datos_demo.py
copy /Y "%RUTA_LOCAL%\README.md"                README.md
copy /Y "%RUTA_LOCAL%\MANUAL_DE_OPERACION.md"   MANUAL_DE_OPERACION.md
copy /Y "%RUTA_LOCAL%\TUTORIAL.md"             TUTORIAL.md
copy /Y "%RUTA_LOCAL%\requirements.txt"         requirements.txt
copy /Y "%RUTA_LOCAL%\INICIAR_SARTIA.bat"       INICIAR_SARTIA.bat
copy /Y "%RUTA_LOCAL%\.gitignore"               .gitignore

REM 4) Confirmar que no se sube nada sensible
git status
echo.
echo Verifica que NO aparezcan: sartia.db, *.pkl, cuentas_tutores.csv, .env
pause

REM 5) Commit y push
git add -A
git commit -m "Sincroniza codigo local: SHAP (shap_utils), lanzador INICIAR_SARTIA, importancia de variables calculada, requirements actualizado"
git push origin %RAMA%
if errorlevel 1 goto :error

echo.
echo LISTO. Anota el hash del commit para citarlo en el entregable:
git rev-parse HEAD
goto :eof

:error
echo.
echo ERROR: revisa mensajes arriba. Si es autenticacion, usa un token:
echo   git remote set-url origin https://<TOKEN>@github.com/esele3112/SARTIA.git
