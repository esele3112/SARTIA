#!/bin/bash
# SARTIA - Sincronizar repositorio GitHub con el codigo local
set -e
REPO=https://github.com/esele3112/SARTIA.git
RAMA=main
RUTA_LOCAL=/ruta/a/tus/archivos/SARTIA

git clone "$REPO" 2>/dev/null || true
cd SARTIA
git fetch origin
git checkout "$RAMA"
git pull origin "$RAMA"
cp -f "$RUTA_LOCAL"/{app.py,shap_utils.py,etl_sartia.py,entrenar_modelo.py,sincronizar_google_sheets.py,generar_datos_demo.py,README.md,MANUAL_DE_OPERACION.md,TUTORIAL.md,requirements.txt,INICIAR_SARTIA.bat,.gitignore} .
git status
read -p "Verifica que no se suban db/pkl/credenciales. Enter para continuar..."
git add -A
git commit -m "Sincroniza codigo local: SHAP (shap_utils), lanzador INICIAR_SARTIA, importancia calculada, requirements actualizado"
git push origin "$RAMA"
git rev-parse HEAD
